export const Client_Id = 'trzjiax9plNjUO_tjeIw';
export const Client_Secret = '7HLXoVGt3Z';