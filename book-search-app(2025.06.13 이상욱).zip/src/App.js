import StackNavigator from "./navigation/StackNavigtaor";

const App = () => {
    return(
        <StackNavigator />
    )
}

export default App;