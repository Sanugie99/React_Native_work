import Signup from "./src/App";

export default Signup;